export default {
    getAllProduct : "http://localhost:3000/product/list",
    signUp:"http://localhost:3000/user/SignUp",
    signIn:"http://localhost:3000/user/SignIn",
    addToCart:"http://localhost:3000/cart/add-to-cart",
    getCart:"http://localhost:3000/cart/getCart",
    productQuantity:"http://localhost:3000/cart/product-quantity"
}